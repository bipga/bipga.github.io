BiPGA API examples

Follow installation.html before running the examples.
The toy example uses temporary data and a custom adapter.
The 48 prepared examples use the full research checkout and its model environment.
Select any registered method through the same API.
