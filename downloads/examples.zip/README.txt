BiPGA API examples

Follow installation.html before running the examples.
The toy example uses temporary data and a custom adapter.
The 48 prepared examples use the full research checkout and its model environment.
Use SparkAlign to select the method in API and CLI calls.
