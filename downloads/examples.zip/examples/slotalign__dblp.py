"""SLOTAlign on the prepared DBLP graph pair.
Install the standalone package and run bipga download --output paper first.
"""
import bpupga as bp

data = bp.Dataset.load(
    "paper/datasets/dblp/base")
method = bp.Algorithm("slotalign", seed=2026, device="cpu")
result = method.align(data.graph1, data.graph2)
metrics = bp.evaluate(result, data, ks=(1, 5, 10))
print(metrics["pair"])
print(metrics["validity"])
