"""iMMNC on the prepared DBLP graph pair.
Run from the research checkout root after the documented API setup.
"""
import bpupga as bp

data = bp.Dataset.load(
    "baseline/data/dblp/bpupga/"
    "rho_s0p6_rho_t0p6/construction_seed_2026")
method = bp.Algorithm("immnc", seed=2026, device="cpu")
result = method.align(data.graph1, data.graph2)
metrics = bp.evaluate(result, data, ks=(1, 5, 10))
print(metrics["pair"])
print(metrics["validity"])
