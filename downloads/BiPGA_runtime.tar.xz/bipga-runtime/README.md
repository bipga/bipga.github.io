# BiPGA complete runtime

The archive contains the standalone Python wheel, all method sources and weights inside the wheel, the complete paper artifact, installation and launch scripts, and a GPU Dockerfile. Use Linux and Python 3.10.

```bash
bash install.sh --cpu
bash bipga.sh doctor --all
bash bipga.sh demo --method all --device cpu --output demo_cpu
bash bipga.sh reproduce --artifact paper --output reproduced
```

Use `bash install.sh --gpu` to install the pinned CUDA-enabled PyTorch. GPU inference also requires an NVIDIA driver and the CUDA compiler. The Docker image supplies the CUDA development environment:

```bash
docker build -f docker/Dockerfile -t bipga-gpu .
docker run --rm --gpus all -v "$PWD:/work" bipga-gpu demo --method all --device cuda:0 --output /work/demo_gpu
```

The host requires NVIDIA Container Toolkit for GPU containers. Installation creates `.venv/` and extracts the bundled paper inputs into `paper/`; it does not run a benchmark. Initial dependency installation requires Internet access.

Source distribution and API documentation: https://bipga.github.io/
