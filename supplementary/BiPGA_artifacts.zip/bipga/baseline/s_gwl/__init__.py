"""Portable scalable Gromov-Wasserstein learning baseline package."""

from .model import SGWL, SGWLConfig

__all__ = ["SGWL", "SGWLConfig"]
