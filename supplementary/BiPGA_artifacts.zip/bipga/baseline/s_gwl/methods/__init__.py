"""S-GWL core methods."""
