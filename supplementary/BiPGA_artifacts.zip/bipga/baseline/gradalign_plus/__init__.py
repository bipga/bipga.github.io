"""Portable topology-only GradAlign+ baseline package."""

from .model import GradAlignPlus, GradAlignPlusConfig

__all__ = ["GradAlignPlus", "GradAlignPlusConfig"]
