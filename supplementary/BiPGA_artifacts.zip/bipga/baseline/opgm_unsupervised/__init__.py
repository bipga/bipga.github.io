"""OPGM-U: isolated unsupervised adaptation; not the supervised OPGMrs model."""
