"""Independent graph-only inference and evaluation for the OPGM adaptation."""
