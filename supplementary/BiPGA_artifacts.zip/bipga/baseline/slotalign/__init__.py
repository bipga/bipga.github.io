"""Portable SLOTAlign baseline package."""

from .model import SLOTAlign, SLOTAlignConfig

__all__ = ["SLOTAlign", "SLOTAlignConfig"]
