"""Isolated CUDA experiment revision; historical sources and runs are immutable."""
