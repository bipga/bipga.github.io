"""Run one configuration used by the paper on its packaged graph input."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def write(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(4<<20),b''):h.update(b)
    return h.hexdigest()


def child(packet_path):
    import numpy as np
    import torch
    import resource
    import time
    import baseline
    from common.seed import seed_everything
    from evaluation.runtime.graph_packet import load_graphs
    from gpu_backend.adapters import construct
    packet=json.loads(packet_path.read_text())
    if set(packet)!={'method','parameters','seed','device','execution'}:raise ValueError('Unexpected inference fields')
    forbidden={'ground_truth','gt','true_k','true_K','true_overlap','dataset','data_root'}
    if forbidden.intersection(packet['parameters']):raise ValueError('Reference information in parameters')
    if not packet['device'].startswith('cuda') or not torch.cuda.is_available():raise RuntimeError('CUDA is required for the paper implementation')
    seed_everything(packet['seed'],deterministic_torch=packet['method']=='s_gwl');torch.manual_seed(packet['seed']);torch.set_num_threads(8)
    graphs=load_graphs(packet_path.parent/'graphs.npz')
    torch.cuda.set_device(packet['device']);torch.cuda.reset_peak_memory_stats()
    started=time.perf_counter()
    model,_=construct(packet['method'],packet['parameters'],packet['seed'],packet['device'],execution=packet['execution'])
    result=model.fit(*graphs)
    torch.cuda.synchronize()
    runtime=dict(time_s=time.perf_counter()-started,ram_gib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,
        gpu_gib=torch.cuda.max_memory_reserved()/1024**3)
    target=packet_path.parent/'fit';target.mkdir()
    write(target/'native_pairs_local.json',dict(pairs=result.predicted_pairs,index_space='consecutive_local'))
    write(target/'fit_metadata.json',dict(method=result.method,seed=packet['seed'],larger_is_better=result.larger_is_better,runtime_sec=result.runtime_sec,runtime=runtime))
    for name in ['score_matrix','cost_matrix','source_embeddings','target_embeddings']:
        a=getattr(result,name)
        if a is not None:np.save(target/(name+'.npy'),a,allow_pickle=False)
    write(target/'fit_seal.json',{p.name:sha(p) for p in target.iterdir()})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list',action='store_true');p.add_argument('--dataset');p.add_argument('--method')
    p.add_argument('--run-id');p.add_argument('--output',type=Path);p.add_argument('--device',default='cuda:0')
    p.add_argument('--dry-run',action='store_true');p.add_argument('--worker',type=Path,help=argparse.SUPPRESS)
    a=p.parse_args()
    if a.worker:child(a.worker);return
    with (ROOT/'experiments/runs.csv').open() as f:rows=list(csv.DictReader(f))
    rows=[r for r in rows if (not a.dataset or r['dataset']==a.dataset) and (not a.method or r['method']==a.method)]
    if a.list:
        print(json.dumps(dict(configurations=len(rows),examples=rows[:10]),indent=2));return
    rows=[r for r in rows if r['run_id']==a.run_id]
    if len(rows)!=1:p.error('Select one --run-id; use --list to view configurations')
    row=rows[0]
    with (ROOT/'datasets/index.csv').open() as f:graphs={g['graph_id']:g for g in csv.DictReader(f)}
    graph=graphs[row['graph_id']];source=ROOT/graph['path']
    params=json.loads((ROOT/'experiments/parameters.json').read_text())[row['parameters_id']]
    if a.dry_run:
        for name in ['G1.edgelist','G2.edgelist','G1.nodes','G2.nodes','Alignment.json']:
            if not (source/name).is_file():raise FileNotFoundError(source/name)
        print(json.dumps(dict(**row,graph_path=graph['path'],parameters=params,starts_inference=False),indent=2));return
    if a.output is None:p.error('--output must name a new directory')
    target=a.output.resolve()
    if target.exists():raise FileExistsError(target)
    target.mkdir(parents=True)
    import baseline
    from common.dataset import load_dataset
    from evaluation.runtime.graph_packet import save_graphs
    data=load_dataset(source)
    save_graphs(target/'graphs.npz',(data.graph1,data.graph2))
    write(target/'packet.json',dict(method=row['method'],parameters=params,seed=int(row['seed']),device=a.device,execution=row['execution']))
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',MKL_NUM_THREADS='8',
        CUBLAS_WORKSPACE_CONFIG=':4096:8',PYTHONHASHSEED=row['seed'])
    with (target/'fit.log').open('w') as log:
        subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',str(target/'packet.json')],
            cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    # Reference labels are kept in the parent and evaluated after the fit seal.
    seal=json.loads((target/'fit/fit_seal.json').read_text())
    for name,expected in seal.items():
        if sha(target/'fit'/name)!=expected:raise ValueError('Fit seal mismatch')
    import numpy as np
    from evaluation.runtime.metrics import evaluate_pair_set,evaluate_matchability,evaluate_ranking_from_matrix
    meta=json.loads((target/'fit/fit_metadata.json').read_text())
    pairs=[tuple(x) for x in json.loads((target/'fit/native_pairs_local.json').read_text())['pairs']]
    truth=data.ground_truth;n,m=len(data.graph1),len(data.graph2)
    pair=evaluate_pair_set(pairs,truth,n,m);node=evaluate_matchability(pairs,truth,n,m)
    file=target/'fit/score_matrix.npy'
    if file.is_file():
        quality=np.load(file,allow_pickle=False)
        if not meta['larger_is_better']:quality=-quality
    else:quality=-np.load(target/'fit/cost_matrix.npy',allow_pickle=False)
    if row['method']=='grampa':
        from evaluation.runtime.grampa_soft_ranking import sinkhorn_soft_scores
        quality=sinkhorn_soft_scores(quality)
    forward=evaluate_ranking_from_matrix(quality,truth)
    reverse=evaluate_ranking_from_matrix(quality.T,{v:u for u,v in truth.items()})
    ranking={k:(forward[k]+reverse[k])/2 for k in ['hits@1','hits@5','hits@10','mrr']}
    write(target/'metrics.json',dict(pair=pair,node_f1=(node['source']['f1']+node['target']['f1'])/2,
        ranking=ranking,runtime=meta['runtime']))
    print('Saved new output to '+str(target))


if __name__=='__main__':main()
