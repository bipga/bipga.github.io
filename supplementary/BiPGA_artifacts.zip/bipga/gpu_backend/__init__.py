"""GPU algorithm kernels and decoders; host use is limited to I/O and launch."""

REVISION='paper_experiments'
