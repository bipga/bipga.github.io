"""Portable six-dataset V1 collection and its construction utilities."""
import sys

sys.modules.setdefault("data", sys.modules[__name__])
