# Data index

| Paper item | Data | Figure or table |
|---|---|---|
| Figure 5 | `data/figure_05/` | `figures/figure_05.pdf` |
| Figure 6 | `data/figure_06/` | `figures/figure_06.pdf` |
| Figure 7 | `data/figure_07/` | `figures/figure_07.pdf` |
| Figure 8 | `data/figure_08/` | `figures/figure_08.pdf` |
| Figure 9 | `data/figure_09/` | `figures/figure_09.pdf` |
| Table II | `data/table_ii/` | `tables/table_02.tex` |
| Table IV | `data/table_iv/` | `tables/table_04.tex` |
| Table V | `data/table_v/` | `tables/table_05.tex` |
| Table VI | `data/table_vi/` | `tables/table_06.tex` |

`values_by_run.csv` contains individual observations; `values.csv` contains summaries. Quality metrics are fractions unless marked as percentages. Runtime is in seconds and memory is in GiB.
