# BiPGA: code, data and experimental results

Code, graph inputs, configurations and results for the ICDE 2027 submission.

See the [complete reproduction guide](REPRODUCE.md) for the graph-to-figure workflow, full experiment execution and expected outputs.

## Contents

- `baseline/`, `gpu_backend/`, `numerical_backend/`: method implementations, numerical routines and pretrained weights.
- `construction/`, `datasets/`: graph construction and experiment inputs.
- `experiments/`: method parameters, seeds and execution configurations.
- `data/`, `figures/`, `tables/`: observations, summaries and paper figures and tables.
- `scripts/`: result reproduction and plotting. See [the data index](DATA_INDEX.md).

Arxiv uses seed 2026 for Figures 5, 6, 8 and 9, and five seeds for Figure 7. Other datasets use seeds 2026–2030. Summaries report the mean and sample standard deviation; standard deviation is blank for a single seed. Natural-pair repetitions use the same graph snapshots.

## Reproduce the supplied results

Use Python 3.10. These commands reproduce results from the supplied observations without fitting models:

```bash
python -m pip install -r requirements-analysis.txt
python scripts/reproduce_results.py --output reproduced
python scripts/summarize.py data/figure_05/values_by_run.csv --output figure05_summary.csv
python scripts/reproduce_diagnostics.py --output diagnostics_recomputed
python scripts/reproduce_source_statistics.py --output table02_recomputed.csv
```

Figure 9 uses the common reference pairs across F, Us, Ut and B, after fitting on the complete input graphs. Its observations include the fixed candidate orders and one-to-one assignments. The evaluation definitions are in `data/figure_09/PROTOCOL.json`.

## Run a model

Model fitting requires Linux, an NVIDIA GPU and the pinned dependencies. The experiment environment uses PyTorch 2.10 with CUDA 12.8. CUDA assignment also requires the CUDA Toolkit 12.9 compiler `nvcc`; set `BPUPGA_NVCC` if it is outside `PATH`.

```bash
python -m pip install torch==2.10.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements.txt
python run.py --list --dataset fbtw --method alpine
python run.py --run-id RUN_ID --output new_run --dry-run
python run.py --run-id RUN_ID --device cuda:0 --output new_run
```

Replace `RUN_ID` with an ID from `experiments/runs.csv`. Each output directory must be new. The runner applies the recorded parameters and execution configuration. Reference correspondences are evaluated after inference. Runtime and memory measurements depend on hardware and resource sharing.

To regenerate diagnostic scores, fit the configurations in `data/figure_09/runs.csv` into `fresh_fits/RUN_ID`, then run:

```bash
python scripts/reproduce_diagnostics.py --fits-root fresh_fits --output diagnostics_from_fits
python scripts/recompute_orbits.py --output exact_orbits
```

## Plot results

The supplied PDFs use the paper layouts. The plotting scripts render the numerical summaries:

```bash
python scripts/plot_results.py --figure 5 --output figure05.pdf
python scripts/plot_figure09.py --no-tex --output-dir figure09_rendered
```

Use `--figure 6`, `7` or `8` for the other figures. Third-party licenses and source notices are included with their implementations.
